package controller;

import entity.Cidade;
import repository.CidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/cidade")
public class CidadeController {

    @Autowired
    private CidadeRepository repository;

    @GetMapping
    public List<Cidade> listar() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<Cidade> salvar(@RequestBody Cidade cidade) {
        Cidade novaCidade = repository.save(cidade);
        return new ResponseEntity<>(novaCidade, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cidade> atualizar(@PathVariable Long id, @RequestBody Cidade cidade) {
        Optional<Cidade> cidadeExistente = repository.findById(id);
        if (cidadeExistente.isPresent()) {
            Cidade cidadeAtualizada = cidadeExistente.get();
            cidadeAtualizada.setNome_cidade(cidade.getNome_cidade());
            cidadeAtualizada.setEstado(cidade.getEstado());
            repository.save(cidadeAtualizada);
            return new ResponseEntity<>(cidadeAtualizada, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}