package entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_cliente;

    private String nome_cliente;
    private String cpf_cliente;

    @ManyToOne
    @JoinColumn(name = "cidade_id_cidade")
    private Cidade cidade;
}