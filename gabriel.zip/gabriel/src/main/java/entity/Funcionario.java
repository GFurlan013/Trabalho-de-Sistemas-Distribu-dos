package entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Funcionario {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_funcionario;

    private String nome_funcionario;
    private String cpf_funcionario;

    @ManyToOne
    @JoinColumn(name = "projeto_id_projeto")
    private Projeto projeto;
}