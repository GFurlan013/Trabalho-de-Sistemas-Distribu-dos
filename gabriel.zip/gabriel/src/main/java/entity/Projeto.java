package entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Projeto {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_projeto;

    private String nome_projeto;
    private String custo;

    @ManyToOne
    @JoinColumn(name = "cliente_id_cliente")
    private Cliente cliente;
}